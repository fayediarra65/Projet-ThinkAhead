package PackageModeTexte;

import java.util.Random;

import javax.swing.JOptionPane;

import PackageModele.AllignementCases;
import PackageModele.Case;
import PackageModele.Grille;
import PackageModele.Joueur;
import PackageModele.Orientation;
import PackageModele.Position;

public class Test {

	public static void main(String[] args) {
		
		 String ligneStr = JOptionPane.showInputDialog(null, "Veuillez saisir le nombre de ligne : ");
	        // Convertit la chaîne en entier
	        int nbrLigne = Integer.parseInt(ligneStr);
	        
	        String colonneStr = JOptionPane.showInputDialog(null, "Veuillez saisir le nombre de colonne : ");
	        int nbrCol = Integer.parseInt(colonneStr);
	        
	        Random random = new Random ();
	        Case c [][] = new Case [nbrLigne] [nbrCol];
	        
	        for (int i = 0 ; i< nbrLigne ; i++) {
	        	for (int j = 0 ; j < nbrCol ; j++) {
	        		int valeur = random.nextInt(c.length);
	        		Position p = new Position (i,j);
	        		c[i][j] = new Case (valeur , p);
	        		
	        	}
	        }
	        
	        Grille g1 = new Grille (c , null);
	        g1.afficherGrille();
	        
	       	        

	}

}
