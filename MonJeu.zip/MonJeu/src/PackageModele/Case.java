package PackageModele;

public class Case {
	int valeur ;
	Position position ;
	Joueur jouePar;
	
	public Case (int valeur , Position position ) {
		this.position = position ;
		this.valeur = valeur;
	}

	public int getValeur() {
		return valeur;
	}


	public Position getPosition() {
		return position;
	}
	



}
