package PackageModele;


public class Grille {
	Case cases [][];
	
	private AllignementCases AllignementActif;

	public Grille (Case  [][] cases , AllignementCases AllignementActif) {
		this.cases = cases;
		this.AllignementActif =  AllignementActif;
		
	}
	
	public void afficherGrille() {
	 for (int i = 0; i < cases.length; i++) {
	        // Ligne supérieure de la cellule
	        for (int j = 0; j < cases[i].length; j++) {
	            System.out.print("+--");
	        }
	        System.out.println("+");

	        // Contenu de la cellule
	        for (int j = 0; j < cases[i].length; j++) {
	            System.out.print("| " + cases[i][j].getValeur());
	        }
	        System.out.println("|");
	    }

	    // Dernière ligne de la grille
	    for (int j = 0; j < cases[0].length; j++) {
	        System.out.print("+--");
	    }
	    System.out.println("+");
		
}

    // Méthode pour définir l'alignement actif dans la grille
    public void setAlignementActif(int num, Orientation orientation) {
        // Corps de la méthode
    }
}





