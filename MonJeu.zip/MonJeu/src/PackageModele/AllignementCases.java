package PackageModele;



	public class AllignementCases {
	    Orientation orientation ;
	    Case[] lesCases;
	    int position;
		public AllignementCases(Orientation orientation, int p, Case[] cases) {
			
			this.orientation = orientation;
			this.lesCases = cases;
			this.position = p;
		} 
	    
	    


}
