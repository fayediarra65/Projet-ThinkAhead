package PackageModele;

public class Orientation {
	private int orientation;

    // Constructeur de la classe Orientation
    public Orientation(int orientation) {
        this.orientation = orientation;
    }
    public void estVerticale () {
    	orientation = 1;
    }
    public void estHorizontale() {
    	orientation = 0;
    }

}
