package PackageModele;

public class Position {
	int pos_x ;
	int pos_y;
	
	public Position (int pos_x , int pos_y) {
		this.pos_x = pos_x;
		this.pos_y = pos_y;
	}

}
