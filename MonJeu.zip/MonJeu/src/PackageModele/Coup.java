package PackageModele;
 
	public class Coup {
		private Joueur joueur ; // le joueur qui a joué le coup
		private Position positionCase ;
		private Orientation orientation ;
		
		
		public Coup(Joueur joueur, Position positionCase, Orientation orientation) {
	        this.joueur = joueur;
	        this.positionCase = positionCase;
	        this.orientation = orientation;
	    }
	
	
	

}
