package PackageModele;

public class JoueurOrdinateur extends Joueur {
	public JoueurOrdinateur (String nom) {
		super (nom); // nom joueurOrdinateur
	}
	public String getNom ()
	{
		return super.getNom();
	}
   
}
