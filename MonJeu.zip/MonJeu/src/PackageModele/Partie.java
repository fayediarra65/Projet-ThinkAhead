package PackageModele;


public class Partie {
	private Grille laGrille ;
	private Joueur [] joueurs;
	private Coup [] lesCoups ;
	private  int []score;
	
	//constructeur de la classe Grille et initialisation des éléments
	public Partie(Grille laGrille, Joueur []  joueurs, Coup[] lesCoups , int []score) {
        this.laGrille = laGrille;
        this.joueurs = new Joueur[]{new JoueurHumain("Joueur Humain"), new JoueurOrdinateur("")};
        this.lesCoups = lesCoups;
        this.score = new int[joueurs.length]; // Crée un tableau de taille 2 pour les scores
       
    }


}
