package PackageModele;

public class JoueurHumain extends Joueur {
	
	public JoueurHumain(String nom) {
		super (nom);  // le nom du jourHumain
	}

	public String getNom() {
		return super.getNom();
	}

}
